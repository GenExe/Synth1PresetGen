Synth1 soundbank by Summa and DocT

contents of archive: 	001sy1-128sy1 (Soundfiles)
			patchnames.pdf
			readme.txt

To install the sounds copy the sy1-files to one of your synth1 soundbank folders.
Please backup the folder before copying the sounds otherwise you will lose its contents. 

Even so we started programming those sounds with the older version of Synth1 we already make use of the extended features of synth1 Version 1.05a. 

We recommend to try the modulation wheel and pitchbender on all our sounds.
Some comments would be appreciated ;-)


Have fun !



Summa	flotorian@freenet.de
DocT	www.trippler.net/music	trippler@widat.de


This sounds can be copied and used freely but it's not allowed 
to sell them or collect them in a non free library without our 
permission..

