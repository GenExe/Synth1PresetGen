------------------------------
 Synth1 Feeltune presets bank
------------------------------

This is a bank of 128 patchs/presets for Synth1 VST v1.12.

The presets cover many genres, mostly electro / dance styles
and should also satisfy 90's and 80's lovers :)

Many presets are receptive to modwheel / pitchbend messages.
If you have questions or requests, feel free to write : contact@feeltune.com.

Chris @ Feeltune.
http://www.feeltune.com

