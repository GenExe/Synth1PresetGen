Bank: YAKA SYNTH1 BANK

Author: YAKA

Contact: yaka93@free.fr

Description : 128 patchs generate with "Synth1 Tools" and "VPG" and reworked one by one.
