Colors of Synth1
128 free Synth1 patches by Saga Musix
http://sagamusix.de/

version 1.1 - released 23 March 2015
I noticed that there was a duplicated patch in the bank, so one copy has been replaced.
New patch: Tiny Percussive Arp. A nice patch for live modification. For example, play around with the FM and saturation parameter and change the effect type to decimator. ;)

version 1.0 - released 22 March 2015
- initial release -

Free to use, but give credits if you're feeling nice. :)

Patch names with "touch" in the name indicate that Aftertouch MIDI messages will give you some nice modulation effects.

Some patches require Synth1 1.13 Beta 2 or newer as they make use of the low-pass diode ladder filter.

How to install:
Extract all files into some folder, go to Synth1's option screen by pressing the "opt" button and point one of the banks to this folder. Done!