Copy LeSynth1.ccm into Synth1's Settings folder and load it to use the LeSynth1 template.

enjoy and please try my other templates!

Mark Jarzewiak

aka shimoda