   Bank: Summa and DocT
Author1: Summa (flotorian@freenet.de)
Author2: DocT (trippler@widat.de)
Contact: www.trippler.net/music

See "patchnames.pdf" for extra details.

