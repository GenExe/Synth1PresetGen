--------------------------------------------------------------------
       Bank: Synth1_Ouroboros_Bank3	
    Plug-In: Synth1   
Description: 128 patches of Synth1 goodness   
     Author: Ouroboros 
    Contact: Yuppiegulag@yahoo.com


[-*By downloading this software you agree to the following terms and conditions.-]

-Use-
   You are free to use this bank of presets in any and all musical productions and arrangements, 
but a mention would be nice! 

-Liability-
    This software is provided "As-Is" and is subject to no further support from the developer.  
    Ouroboros is NOT liable for ANY damage sustained to your computer due to the use of this software.

-Copying-
    Though you are free to make use of the sounds in this bank, it IS Copyrighted Material!!!
You MAY NOT in ANY way, shape, or form, Sell this bank or any part of it's content for ANY purpose without 
the express written consent of the author! Inclusion of presets in a compilation is fine where credited.
--------------------------------------------------------------------
I'd love to hear how you use these!  Drop me a line.
--------------------------------------------------------------------
