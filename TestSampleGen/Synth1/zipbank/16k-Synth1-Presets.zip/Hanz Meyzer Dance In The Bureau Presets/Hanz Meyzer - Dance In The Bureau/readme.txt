Hanz Meyzer - Dance In The Bureau
Synthwave Soundbank for Synth1 by Jurek Raben

All presets from this song entry for KVR OSC #68 competition (Synth1 only track):
https://archive.org/download/OSC68Synth1/Hanz%20Meyzer%20-%20Dance%20in%20the%20Bureau%20%28Synth1%20only%29.mp3

KVR OSC #68 page:
https://sites.google.com/site/kvrosc/osc-68-synth1

Forum thread:
http://www.kvraudio.com/forum/viewtopic.php?f=1&t=421700

Contact me if you like at: jr@virtualcreations.de

Hope you like it!
