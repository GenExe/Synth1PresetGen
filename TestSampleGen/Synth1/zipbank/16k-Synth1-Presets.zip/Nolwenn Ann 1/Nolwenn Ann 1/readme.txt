--------------------------
- Synth1 bank by Nolwenn -
--------------------------


This is a bank of 128 presets.
I tried to recreate a maximum of "clich� sounds", just for the fun :-)
The last 32 presets are "drumkit" and "GM" stuff.
Synth1 can do everything :-)
All these sounds have been made with v1.06, they wouldn't sound the same in older versions. 
Warning : the preset 92 is a bit loud.


Have fun.


With love
Nolwenn
n0lwenn@netcourrier.com



These presets can be used freely but it's not allowed to sell them or collect them in a non free library.